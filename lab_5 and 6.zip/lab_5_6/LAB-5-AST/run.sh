#!/bin/bash
lex lexer.l
yacc -d parser.y
gcc -g y.tab.c lex.yy.c -lfl

./a.out<test_input_1.c >output_1.txt
./a.out<test_input_2.c >output_2.txt
